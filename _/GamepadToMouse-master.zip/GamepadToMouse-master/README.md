# GamepadToMouse

Press Home key on keyboard to enable/disable virtual mouse.  
You can also use ReWASD to replace the keys on your gamepad to Home key
